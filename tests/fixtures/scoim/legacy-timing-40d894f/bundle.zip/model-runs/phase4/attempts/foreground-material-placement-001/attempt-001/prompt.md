対象配置の前景音符を作ってください。同じマテリアルの再利用または変奏では、比較元の特徴を保ちながら完全な同一コピーにしないでください。遷移では前後の境界を自然につないでください。ID、JSON path、伴奏、演奏表現は返さず、指定されたSchemaだけに従ってください。

入力: {"target": {"comparison_contexts": [], "harmonic_intent": "主調を示して閉じる。", "length_units": 12, "material_description": "短い主題。", "section_description": "主題を示す。", "shared_harmony": [{"at_units": 0, "duration_units": 12, "quality": "major", "root_pitch_class": 0}], "transition": false}, "whole_piece": {"mode": "major", "overall_harmonic_story": "主調を示して閉じる。", "tonal_center": 0}}
